import { useRef, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { ArrowDown } from 'lucide-react';
import { Message, User } from '../../types';
import MessageItem from './MessageItem';
import { useAuthStore } from '../../stores/authStore';
import { useChatStore } from '../../stores/chatStore';
import { useUserStore } from '../../stores/userStore';
import ForwardMessageDialog from './ForwardMessageDialog';

interface MessageListProps {
  messages: Message[];
  typingUser: User | null;
  chatId: string;
  onReply: (messageId: string) => void;
}

export default function MessageList({ 
  messages, 
  typingUser, 
  chatId,
  onReply
}: MessageListProps) {
  const { user } = useAuthStore();
  const { addReaction, deleteMessage, forwardMessage, chats } = useChatStore();
  const { users } = useUserStore();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [highlightedMessageId, setHighlightedMessageId] = useState<string | null>(null);
  const [forwardingMessage, setForwardingMessage] = useState<string | null>(null);

  // Group messages by date
  const groupedMessages: Record<string, Message[]> = {};
  
  messages.forEach((message) => {
    const date = format(new Date(message.createdAt), 'MMMM d, yyyy');
    if (!groupedMessages[date]) {
      groupedMessages[date] = [];
    }
    groupedMessages[date].push(message);
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleScroll = () => {
    if (containerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = containerRef.current;
      setShowScrollButton(scrollHeight - scrollTop - clientHeight > 300);
    }
  };

  useEffect(() => {
    if (messages.length > 0) {
      scrollToBottom();
    }
  }, [chatId]);

  useEffect(() => {
    if (containerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = containerRef.current;
      const isAtBottom = scrollHeight - scrollTop - clientHeight < 200;
      
      if (isAtBottom) {
        scrollToBottom();
      }
    }
  }, [messages]);

  const filteredMessages = searchTerm.trim() 
    ? messages.filter(m => m.text.toLowerCase().includes(searchTerm.toLowerCase()))
    : messages;

  if (!user) return null;

  return (
    <>
      <div 
        className="flex-1 overflow-y-auto p-4 pt-2 space-y-4"
        ref={containerRef}
        onScroll={handleScroll}
      >
        {Object.entries(groupedMessages).map(([date, dateMessages]) => (
          <div key={date} className="space-y-3">
            <div className="flex justify-center sticky top-0 z-10">
              <div className="bg-blue-900/30 px-3 py-1 rounded-full text-xs text-blue-200">
                {date}
              </div>
            </div>
            
            {dateMessages.map((message, index) => {
              const previousMessage = index > 0 ? dateMessages[index - 1] : null;
              const nextMessage = index < dateMessages.length - 1 ? dateMessages[index + 1] : null;
              
              const isFirstInGroup = !previousMessage || previousMessage.senderId !== message.senderId;
              const isLastInGroup = !nextMessage || nextMessage.senderId !== message.senderId;
              
              return (
                <MessageItem
                  key={message.id}
                  message={message}
                  isCurrentUser={message.senderId === user?.id}
                  isFirstInGroup={isFirstInGroup}
                  isLastInGroup={isLastInGroup}
                  isHighlighted={message.id === highlightedMessageId}
                  replyToMessage={messages.find(m => m.id === message.replyTo)}
                  onReaction={(emoji) => addReaction(message.id, emoji)}
                  onReply={() => onReply(message.id)}
                  onForward={() => setForwardingMessage(message.id)}
                  onDelete={(type) => deleteMessage(message.id, type)}
                />
              );
            })}
          </div>
        ))}

        {typingUser && (
          <div className="flex items-center gap-2 ml-4">
            <div className="flex space-x-1">
              {[0, 1, 2].map((dot) => (
                <motion.div
                  key={dot}
                  className="w-2 h-2 rounded-full bg-slate-300"
                  animate={{ y: [0, -5, 0] }}
                  transition={{
                    duration: 0.6,
                    repeat: Infinity,
                    delay: dot * 0.1,
                  }}
                />
              ))}
            </div>
            <span className="text-sm text-slate-400">{typingUser.name} is typing...</span>
          </div>
        )}
        
        <div ref={messagesEndRef} />
        
        {showScrollButton && (
          <motion.button
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="fixed bottom-24 right-8 z-10 p-2 rounded-full bg-blue-600 text-white shadow-lg"
            onClick={scrollToBottom}
          >
            <ArrowDown size={20} />
          </motion.button>
        )}
      </div>

      <ForwardMessageDialog
        isOpen={!!forwardingMessage}
        onClose={() => setForwardingMessage(null)}
        onForward={(chatIds) => {
          if (forwardingMessage) {
            forwardMessage(forwardingMessage, chatIds);
          }
        }}
        chats={chats}
        users={users}
        currentUser={user}
      />
    </>
  );
}