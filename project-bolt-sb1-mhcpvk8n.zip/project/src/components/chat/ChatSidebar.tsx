import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, UserPlus, Settings, LogOut, Menu, X } from 'lucide-react';

import { useAuthStore } from '../../stores/authStore';
import { useChatStore } from '../../stores/chatStore';
import { useUserStore } from '../../stores/userStore';
import ConversationItem from './ConversationItem';
import UserAvatar from '../ui/UserAvatar';

export default function ChatSidebar() {
  const { chatId } = useParams();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { chats, fetchChats, isLoading } = useChatStore();
  const { users, fetchUsers } = useUserStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  useEffect(() => {
    fetchChats();
    fetchUsers();
  }, [fetchChats, fetchUsers]);

  const filteredChats = chats.filter(chat => {
    if (!searchQuery.trim()) return true;
    
    // Find the other participant
    const otherParticipantId = chat.participants.find(id => id !== user?.id);
    const otherUser = users.find(u => u.id === otherParticipantId);
    
    // Search by user name
    if (otherUser && otherUser.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return true;
    }
    
    // Search in last message if exists
    if (chat.lastMessage && chat.lastMessage.text.toLowerCase().includes(searchQuery.toLowerCase())) {
      return true;
    }
    
    return false;
  });

  // Sort chats by last message date (most recent first)
  const sortedChats = [...filteredChats].sort((a, b) => {
    const dateA = a.lastMessage?.createdAt || a.updatedAt;
    const dateB = b.lastMessage?.createdAt || b.updatedAt;
    return new Date(dateB).getTime() - new Date(dateA).getTime();
  });

  const handleSelectChat = (id: string) => {
    navigate(`/chat/${id}`);
    setIsMobileSidebarOpen(false);
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const sidebarContent = (
    <>
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {user && <UserAvatar user={user} size="md" />}
            <div>
              <h3 className="font-medium text-slate-100">{user?.name}</h3>
              <p className="text-xs text-slate-400">{user?.department}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800">
              <Settings size={20} />
            </button>
            <button 
              className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
              onClick={handleLogout}
            >
              <LogOut size={20} />
            </button>
            <button 
              className="md:hidden p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
              onClick={() => setIsMobileSidebarOpen(false)}
            >
              <X size={20} />
            </button>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="Search conversations..."
            className="input pl-10 bg-slate-800/50 w-full"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      
      <div className="flex items-center justify-between px-4 py-2">
        <h3 className="font-medium text-slate-300">Recent Chats</h3>
        <button className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800">
          <UserPlus size={18} />
        </button>
      </div>
      
      <div className="overflow-y-auto flex-1">
        {isLoading ? (
          <div className="flex flex-col gap-2 p-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="p-3 rounded-md bg-slate-800/50 animate-pulse">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-slate-700"></div>
                  <div className="flex-1">
                    <div className="h-4 w-24 bg-slate-700 rounded mb-2"></div>
                    <div className="h-3 w-32 bg-slate-700 rounded"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : sortedChats.length === 0 ? (
          <div className="p-4 text-center text-slate-400">
            {searchQuery ? 'No matching conversations found' : 'No conversations yet'}
          </div>
        ) : (
          <div className="flex flex-col gap-1 py-1">
            {sortedChats.map(chat => {
              // Find the other participant
              const otherParticipantId = chat.participants.find(id => id !== user?.id);
              const otherUser = users.find(u => u.id === otherParticipantId);
              
              if (!otherUser) return null;
              
              return (
                <ConversationItem
                  key={chat.id}
                  user={otherUser}
                  lastMessage={chat.lastMessage}
                  isActive={chat.id === chatId}
                  onClick={() => handleSelectChat(chat.id)}
                />
              );
            })}
          </div>
        )}
      </div>
    </>
  );

  return (
    <>
      {/* Mobile menu toggle */}
      <button 
        className="md:hidden fixed top-4 left-4 z-30 p-2 rounded-md bg-slate-800 text-slate-200"
        onClick={() => setIsMobileSidebarOpen(true)}
      >
        <Menu size={24} />
      </button>
      
      {/* Mobile sidebar */}
      <motion.div 
        className="md:hidden fixed inset-0 z-20 bg-background-darker"
        initial={{ x: '-100%' }}
        animate={{ x: isMobileSidebarOpen ? 0 : '-100%' }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
      >
        <div className="flex flex-col h-full">
          {sidebarContent}
        </div>
      </motion.div>
      
      {/* Desktop sidebar */}
      <div className="hidden md:flex flex-col w-80 border-r border-slate-800 bg-background-dark h-full">
        {sidebarContent}
      </div>
    </>
  );
}