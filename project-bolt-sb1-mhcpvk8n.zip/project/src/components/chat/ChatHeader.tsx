import { useState } from 'react';
import { format } from 'date-fns';
import { User, Chat } from '../../types';
import { Phone, Video, Search, MoreVertical, Users, UserPlus, Settings } from 'lucide-react';
import UserAvatar from '../ui/UserAvatar';
import { motion, AnimatePresence } from 'framer-motion';
import SettingsDialog from './SettingsDialog';

interface ChatHeaderProps {
  chat: Chat;
  participants: User[];
  onOpenSearch: () => void;
  onAddMembers: () => void;
}

export default function ChatHeader({ chat, participants, onOpenSearch, onAddMembers }: ChatHeaderProps) {
  const [showMenu, setShowMenu] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const getLastSeen = (user: User) => {
    if (user.status === 'online') return 'Online';
    if (user.status === 'away') return 'Away';
    if (user.lastSeen) {
      const now = new Date();
      const lastSeen = new Date(user.lastSeen);
      const diffHours = Math.abs(now.getTime() - lastSeen.getTime()) / 36e5;
      
      if (diffHours < 24) {
        return `Last seen today at ${format(lastSeen, 'HH:mm')}`;
      } else if (diffHours < 48) {
        return `Last seen yesterday at ${format(lastSeen, 'HH:mm')}`;
      } else {
        return `Last seen ${format(lastSeen, 'MMM d')} at ${format(lastSeen, 'HH:mm')}`;
      }
    }
    return 'Offline';
  };

  if (!chat || !participants.length) {
    return null;
  }

  return (
    <>
      <div className="flex items-center justify-between py-3 px-4 border-b border-slate-800 bg-background-dark">
        <div className="flex items-center gap-3">
          {chat?.isGroup ? (
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
                <Users size={20} className="text-white" />
              </div>
            </div>
          ) : (
            <UserAvatar user={participants[0]} size="sm" showStatus />
          )}
          
          <div>
            <h3 className="font-medium text-slate-100">
              {chat?.isGroup ? chat.name : participants[0]?.name}
              {chat?.isGroup && (
                <span className="ml-2 text-xs text-slate-400">
                  {participants.length} members
                </span>
              )}
            </h3>
            {!chat?.isGroup && participants[0] && (
              <div className="flex items-center">
                <span className="text-xs text-slate-400">
                  {getLastSeen(participants[0])}
                </span>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-1">
          <button className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800">
            <Phone size={20} />
          </button>
          <button className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800">
            <Video size={20} />
          </button>
          <button 
            className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
            onClick={onOpenSearch}
          >
            <Search size={20} />
          </button>
          <div className="relative">
            <button 
              className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
              onClick={() => setShowMenu(!showMenu)}
            >
              <MoreVertical size={20} />
            </button>
            
            <AnimatePresence>
              {showMenu && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute right-0 top-full mt-1 w-48 py-1 bg-slate-800 rounded-md shadow-lg z-50"
                >
                  {chat?.isGroup && (
                    <button
                      onClick={() => {
                        onAddMembers();
                        setShowMenu(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-slate-200 hover:bg-slate-700 flex items-center gap-2"
                    >
                      <UserPlus size={16} />
                      Add Members
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setShowSettings(true);
                      setShowMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left text-sm text-slate-200 hover:bg-slate-700 flex items-center gap-2"
                  >
                    <Settings size={16} />
                    Settings
                  </button>
                  <button
                    className="w-full px-4 py-2 text-left text-sm text-slate-200 hover:bg-slate-700"
                  >
                    Clear Chat
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      <SettingsDialog 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
      />
    </>
  );
}