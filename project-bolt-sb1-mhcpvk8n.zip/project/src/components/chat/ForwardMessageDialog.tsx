import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, Search } from 'lucide-react';
import { Chat, User } from '../../types';
import UserAvatar from '../ui/UserAvatar';

interface ForwardMessageDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onForward: (chatIds: string[]) => void;
  chats: Chat[];
  users: User[];
  currentUser: User;
}

export default function ForwardMessageDialog({
  isOpen,
  onClose,
  onForward,
  chats,
  users,
  currentUser
}: ForwardMessageDialogProps) {
  const [selectedChats, setSelectedChats] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredChats = chats.filter(chat => {
    if (!searchQuery.trim()) return true;
    
    if (chat.isGroup && chat.name?.toLowerCase().includes(searchQuery.toLowerCase())) {
      return true;
    }
    
    const otherUser = users.find(u => 
      chat.participants.includes(u.id) && u.id !== currentUser.id
    );
    
    return otherUser?.name.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const handleForward = () => {
    if (selectedChats.length > 0) {
      onForward(selectedChats);
      setSelectedChats([]);
      onClose();
    }
  };

  const toggleChat = (chatId: string) => {
    setSelectedChats(prev =>
      prev.includes(chatId)
        ? prev.filter(id => id !== chatId)
        : [...prev, chatId]
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
        >
          <motion.div
            initial={{ scale: 0.95 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0.95 }}
            className="bg-slate-900 rounded-xl shadow-xl w-full max-w-md"
          >
            <div className="flex items-center justify-between p-4 border-b border-slate-800">
              <h2 className="text-xl font-semibold text-slate-100">Forward Message</h2>
              <button
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-4">
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  placeholder="Search chats..."
                  className="input pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto">
                {filteredChats.map(chat => {
                  const otherUser = users.find(u => 
                    chat.participants.includes(u.id) && u.id !== currentUser.id
                  );

                  return (
                    <div
                      key={chat.id}
                      onClick={() => toggleChat(chat.id)}
                      className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors ${
                        selectedChats.includes(chat.id)
                          ? 'bg-blue-600/20 border border-blue-500/50'
                          : 'hover:bg-slate-800/50'
                      }`}
                    >
                      {chat.isGroup ? (
                        <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center">
                          <span className="text-white font-medium">
                            {chat.name?.slice(0, 2).toUpperCase()}
                          </span>
                        </div>
                      ) : (
                        otherUser && <UserAvatar user={otherUser} size="sm" />
                      )}
                      <span className="flex-1 text-slate-200">
                        {chat.isGroup ? chat.name : otherUser?.name}
                      </span>
                      {selectedChats.includes(chat.id) && (
                        <Check size={20} className="text-blue-500" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end gap-2 p-4 border-t border-slate-800">
              <button
                onClick={onClose}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                onClick={handleForward}
                className="btn btn-primary"
                disabled={selectedChats.length === 0}
              >
                Forward ({selectedChats.length})
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}