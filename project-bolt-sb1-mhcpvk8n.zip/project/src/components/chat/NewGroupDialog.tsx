import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Users, Check } from 'lucide-react';
import { User } from '../../types';
import UserAvatar from '../ui/UserAvatar';

interface NewGroupDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateGroup: (name: string, participants: string[]) => void;
  availableUsers: User[];
}

export default function NewGroupDialog({ 
  isOpen, 
  onClose, 
  onCreateGroup, 
  availableUsers 
}: NewGroupDialogProps) {
  const [groupName, setGroupName] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [error, setError] = useState('');

  const handleCreateGroup = () => {
    if (!groupName.trim()) {
      setError('Please enter a group name');
      return;
    }
    
    if (selectedUsers.length < 2) {
      setError('Please select at least 2 participants');
      return;
    }
    
    onCreateGroup(groupName, selectedUsers);
    setGroupName('');
    setSelectedUsers([]);
    setError('');
    onClose();
  };

  const toggleUser = (userId: string) => {
    setSelectedUsers(prev => 
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
        >
          <motion.div
            initial={{ scale: 0.95 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0.95 }}
            className="bg-slate-900 rounded-xl shadow-xl w-full max-w-md"
          >
            <div className="flex items-center justify-between p-4 border-b border-slate-800">
              <h2 className="text-xl font-semibold text-slate-100">Create New Group</h2>
              <button
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-4">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">
                    Group Name
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                      <Users size={20} className="text-slate-400" />
                    </div>
                    <input
                      type="text"
                      value={groupName}
                      onChange={(e) => setGroupName(e.target.value)}
                      placeholder="Enter group name"
                      className="input pl-10"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">
                    Select Participants ({selectedUsers.length} selected)
                  </label>
                  <div className="mt-2 space-y-2 max-h-60 overflow-y-auto">
                    {availableUsers.map(user => (
                      <div
                        key={user.id}
                        onClick={() => toggleUser(user.id)}
                        className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors ${
                          selectedUsers.includes(user.id)
                            ? 'bg-blue-600/20 border border-blue-500/50'
                            : 'hover:bg-slate-800/50'
                        }`}
                      >
                        <UserAvatar user={user} size="sm" />
                        <span className="flex-1 text-slate-200">{user.name}</span>
                        {selectedUsers.includes(user.id) && (
                          <Check size={20} className="text-blue-500" />
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {error && (
                  <p className="text-sm text-red-500">{error}</p>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2 p-4 border-t border-slate-800">
              <button
                onClick={onClose}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateGroup}
                className="btn btn-primary"
                disabled={!groupName.trim() || selectedUsers.length < 2}
              >
                Create Group
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}