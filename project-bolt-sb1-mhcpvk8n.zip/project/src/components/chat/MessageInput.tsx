import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Paperclip, Send, Smile, Mic, X } from 'lucide-react';
import { Message } from '../../types';
import { useChatStore } from '../../stores/chatStore';

interface MessageInputProps {
  chatId: string;
  replyToMessage: Message | null;
  onCancelReply: () => void;
}

export default function MessageInput({ 
  chatId, 
  replyToMessage, 
  onCancelReply 
}: MessageInputProps) {
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const { sendMessage, setTypingStatus } = useChatStore();
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Focus input when replying to a message
  useEffect(() => {
    if (replyToMessage && inputRef.current) {
      inputRef.current.focus();
    }
  }, [replyToMessage]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessage(e.target.value);
    
    // Handle typing indicator
    if (!isTyping) {
      setIsTyping(true);
      setTypingStatus(chatId, true);
    }
    
    // Reset typing timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
      setTypingStatus(chatId, false);
    }, 3000);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (message.trim()) {
      sendMessage(chatId, message, replyToMessage?.id);
      setMessage('');
      
      if (replyToMessage) {
        onCancelReply();
      }
      
      // Clear typing indicator
      if (isTyping) {
        setIsTyping(false);
        setTypingStatus(chatId, false);
        
        if (typingTimeoutRef.current) {
          clearTimeout(typingTimeoutRef.current);
        }
      }
    }
  };

  return (
    <div className="px-4 py-3 border-t border-slate-800 bg-background-dark">
      <AnimatePresence>
        {replyToMessage && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-slate-800/50 p-2 rounded-md mb-2 flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <div className="w-1 bg-blue-500 self-stretch rounded-full"></div>
              <div>
                <p className="text-xs text-blue-400">Replying to message</p>
                <p className="text-sm text-slate-300 truncate">{replyToMessage.text}</p>
              </div>
            </div>
            <button 
              className="text-slate-400 hover:text-slate-200 p-1"
              onClick={onCancelReply}
            >
              <X size={16} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
      
      <form onSubmit={handleSendMessage} className="flex items-center gap-2">
        <button 
          type="button"
          className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
        >
          <Paperclip size={20} />
        </button>
        
        <div className="relative flex-1">
          <input
            ref={inputRef}
            type="text"
            value={message}
            onChange={handleInputChange}
            placeholder="Type a message"
            className="input py-2.5 pr-10 bg-slate-800"
          />
          <button 
            type="button"
            className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 p-1.5"
          >
            <Smile size={20} />
          </button>
        </div>
        
        {message.trim() ? (
          <button 
            type="submit"
            className="p-2.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Send size={18} />
          </button>
        ) : (
          <button
            type="button"
            className="p-2.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300"
          >
            <Mic size={18} />
          </button>
        )}
      </form>
    </div>
  );
}