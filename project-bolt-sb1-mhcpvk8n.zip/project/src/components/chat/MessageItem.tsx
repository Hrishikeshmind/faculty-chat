import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { Smile, Reply, CheckCheck, Check, CornerUpLeft, Forward, Trash2, MoreVertical } from 'lucide-react';
import { Message, User } from '../../types';
import { useAuthStore } from '../../stores/authStore';

interface MessageItemProps {
  message: Message;
  isCurrentUser: boolean;
  isFirstInGroup: boolean;
  isLastInGroup: boolean;
  isHighlighted: boolean;
  replyToMessage?: Message;
  onReaction: (emoji: string) => void;
  onReply: () => void;
  onForward: () => void;
  onDelete: (type: 'me' | 'everyone') => void;
}

export default function MessageItem({
  message,
  isCurrentUser,
  isFirstInGroup,
  isLastInGroup,
  isHighlighted,
  replyToMessage,
  onReaction,
  onReply,
  onForward,
  onDelete
}: MessageItemProps) {
  const [showReactions, setShowReactions] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const messageRef = useRef<HTMLDivElement>(null);
  const { user } = useAuthStore();

  const getStatusIcon = (status: Message['status']) => {
    switch (status) {
      case 'sent':
        return <Check size={14} className="text-slate-400" />;
      case 'delivered':
        return <CheckCheck size={14} className="text-slate-400" />;
      case 'read':
        return <CheckCheck size={14} className="text-blue-500" />;
      default:
        return null;
    }
  };

  const reactionEmojis = ['👍', '❤️', '😂', '😮', '😢', '👏'];

  // Check if message can be deleted for everyone (within 5 minutes)
  const canDeleteForEveryone = () => {
    const messageTime = new Date(message.createdAt).getTime();
    const now = new Date().getTime();
    const fiveMinutes = 5 * 60 * 1000;
    return now - messageTime <= fiveMinutes;
  };

  return (
    <div
      ref={messageRef}
      className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'}`}
    >
      {/* Forwarded label */}
      {message.forwarded && (
        <div className={`text-xs text-slate-400 mb-1 ${
          isCurrentUser ? 'mr-3' : 'ml-3'
        }`}>
          <Forward size={12} className="inline mr-1" />
          Forwarded
        </div>
      )}

      {/* Reply reference */}
      {replyToMessage && (
        <div 
          className={`flex items-center gap-2 text-xs mb-1 ${
            isCurrentUser ? 'mr-3' : 'ml-3'
          }`}
        >
          <CornerUpLeft size={12} className="text-slate-400" />
          <div className={`${
            isCurrentUser ? 'bg-blue-800/50' : 'bg-slate-700/50'
          } py-1 px-2 rounded-md text-slate-300 max-w-xs truncate`}>
            {replyToMessage.text}
          </div>
        </div>
      )}

      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg relative group ${
          isHighlighted ? 'bg-blue-900/30' : ''
        }`}
      >
        {/* Message bubble */}
        <div 
          className={`py-2 px-3 rounded-lg ${
            isCurrentUser 
              ? 'chat-bubble-sent mr-2' 
              : 'chat-bubble-received ml-2'
          } ${
            !isLastInGroup && 'mb-1'
          }`}
        >
          <p className="text-sm">{message.text}</p>
          <div className={`text-xs mt-1 ${
            isCurrentUser ? 'text-blue-200' : 'text-slate-400'
          } flex justify-end items-center gap-1`}>
            <span>
              {format(new Date(message.createdAt), 'HH:mm')}
            </span>
            {isCurrentUser && message.status && getStatusIcon(message.status)}
          </div>
        </div>
        
        {/* Message actions */}
        <div className={`absolute ${
          isCurrentUser ? '-left-16' : '-right-16'
        } top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col gap-2`}>
          <button 
            className="p-1.5 bg-slate-800 rounded-full hover:bg-slate-700 text-slate-300"
            onClick={() => setShowReactions(!showReactions)}
          >
            <Smile size={16} />
          </button>
          <button 
            className="p-1.5 bg-slate-800 rounded-full hover:bg-slate-700 text-slate-300"
            onClick={onReply}
          >
            <Reply size={16} />
          </button>
          <button 
            className="p-1.5 bg-slate-800 rounded-full hover:bg-slate-700 text-slate-300"
            onClick={onForward}
          >
            <Forward size={16} />
          </button>
          {isCurrentUser && (
            <button 
              className="p-1.5 bg-slate-800 rounded-full hover:bg-slate-700 text-slate-300"
              onClick={() => setShowMenu(!showMenu)}
            >
              <MoreVertical size={16} />
            </button>
          )}
        </div>

        {/* Delete menu */}
        <AnimatePresence>
          {showMenu && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`absolute ${
                isCurrentUser ? 'right-0' : 'left-0'
              } bottom-full mb-2 bg-slate-800 rounded-lg shadow-lg z-20`}
            >
              <button
                onClick={() => {
                  onDelete('me');
                  setShowMenu(false);
                }}
                className="flex items-center gap-2 px-4 py-2 text-sm text-red-400 hover:bg-slate-700 rounded-t-lg w-full"
              >
                <Trash2 size={16} />
                Delete for me
              </button>
              {canDeleteForEveryone() && (
                <button
                  onClick={() => {
                    onDelete('everyone');
                    setShowMenu(false);
                  }}
                  className="flex items-center gap-2 px-4 py-2 text-sm text-red-400 hover:bg-slate-700 rounded-b-lg w-full"
                >
                  <Trash2 size={16} />
                  Delete for everyone
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Reaction buttons */}
        <AnimatePresence>
          {showReactions && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className={`absolute ${
                isCurrentUser ? 'right-2' : 'left-2'
              } -top-10 bg-slate-800 p-1 rounded-full flex gap-1 shadow-lg z-10`}
            >
              {reactionEmojis.map(emoji => (
                <button 
                  key={emoji}
                  className="p-1 hover:bg-slate-700 rounded-full transition-colors"
                  onClick={() => onReaction(emoji)}
                >
                  {emoji}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
      
      {/* Display reactions */}
      {message.reactions.length > 0 && (
        <div 
          className={`flex gap-1 mt-1 ${
            isCurrentUser ? 'mr-2' : 'ml-2'
          }`}
        >
          {message.reactions.map((reaction, index) => (
            <div 
              key={`${reaction.userId}-${index}`} 
              className="bg-slate-800 px-1.5 py-0.5 rounded-full flex items-center text-xs"
            >
              <span>{reaction.emoji}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}