import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Moon, Bell, Lock, Image, Palette, Trash2, Shield, HelpCircle, LogOut } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';
import UserAvatar from '../ui/UserAvatar';

interface SettingsDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SettingsDialog({ isOpen, onClose }: SettingsDialogProps) {
  const { user, logout } = useAuthStore();
  const [activeTab, setActiveTab] = useState<'general' | 'privacy' | 'notifications'>('general');

  const handleLogout = () => {
    logout();
    onClose();
  };

  const tabs = [
    { id: 'general', label: 'General' },
    { id: 'privacy', label: 'Privacy' },
    { id: 'notifications', label: 'Notifications' }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
        >
          <motion.div
            initial={{ scale: 0.95 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0.95 }}
            className="bg-slate-900 rounded-xl shadow-xl w-full max-w-2xl h-[600px] flex"
          >
            {/* Sidebar */}
            <div className="w-64 border-r border-slate-800 p-4">
              {user && (
                <div className="flex items-center gap-3 p-2 mb-6">
                  <UserAvatar user={user} size="md" />
                  <div>
                    <h3 className="font-medium text-slate-100">{user.name}</h3>
                    <p className="text-sm text-slate-400">{user.department}</p>
                  </div>
                </div>
              )}

              <div className="space-y-1">
                {tabs.map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                      activeTab === tab.id
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 flex flex-col">
              <div className="flex items-center justify-between p-4 border-b border-slate-800">
                <h2 className="text-xl font-semibold text-slate-100">Settings</h2>
                <button
                  onClick={onClose}
                  className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4">
                {activeTab === 'general' && (
                  <div className="space-y-4">
                    <div className="p-3 rounded-lg hover:bg-slate-800/50 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-violet-600/20 text-violet-400">
                          <Moon size={20} />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-200">Theme</h3>
                          <p className="text-sm text-slate-400">Dark</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 rounded-lg hover:bg-slate-800/50 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-blue-600/20 text-blue-400">
                          <Image size={20} />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-200">Chat Wallpaper</h3>
                          <p className="text-sm text-slate-400">Default</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 rounded-lg hover:bg-slate-800/50 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-green-600/20 text-green-400">
                          <Palette size={20} />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-200">Accent Color</h3>
                          <p className="text-sm text-slate-400">Blue</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 rounded-lg hover:bg-slate-800/50 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-red-600/20 text-red-400">
                          <Trash2 size={20} />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-200">Clear All Chats</h3>
                          <p className="text-sm text-slate-400">Delete all messages</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'privacy' && (
                  <div className="space-y-4">
                    <div className="p-3 rounded-lg hover:bg-slate-800/50 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-blue-600/20 text-blue-400">
                          <Lock size={20} />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-200">Privacy</h3>
                          <p className="text-sm text-slate-400">Last seen, Profile photo</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 rounded-lg hover:bg-slate-800/50 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-green-600/20 text-green-400">
                          <Shield size={20} />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-200">Two-Step Verification</h3>
                          <p className="text-sm text-slate-400">Add extra security to your account</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'notifications' && (
                  <div className="space-y-4">
                    <div className="p-3 rounded-lg hover:bg-slate-800/50 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-full bg-amber-600/20 text-amber-400">
                          <Bell size={20} />
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-200">Message Notifications</h3>
                          <p className="text-sm text-slate-400">Show notifications for new messages</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-4 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => {}}
                    className="flex items-center gap-2 text-slate-400 hover:text-slate-300"
                  >
                    <HelpCircle size={18} />
                    <span>Help</span>
                  </button>
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-2 text-red-400 hover:text-red-300"
                  >
                    <LogOut size={18} />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}