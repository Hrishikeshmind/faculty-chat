import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { CheckCheck, Check } from 'lucide-react';
import { User, Message } from '../../types';
import UserAvatar from '../ui/UserAvatar';

interface ConversationItemProps {
  user: User;
  lastMessage?: Message;
  isActive: boolean;
  onClick: () => void;
}

export default function ConversationItem({ 
  user, 
  lastMessage, 
  isActive, 
  onClick 
}: ConversationItemProps) {
  const getStatusIcon = (status: Message['status']) => {
    switch (status) {
      case 'sent':
        return <Check size={16} className="text-slate-400" />;
      case 'delivered':
        return <CheckCheck size={16} className="text-slate-400" />;
      case 'read':
        return <CheckCheck size={16} className="text-blue-500" />;
      default:
        return null;
    }
  };

  return (
    <motion.div
      whileHover={{ x: 5 }}
      onClick={onClick}
      className={`flex items-center gap-3 p-3 cursor-pointer transition-colors ${
        isActive 
          ? 'bg-slate-800' 
          : 'hover:bg-slate-800/50'
      }`}
    >
      <UserAvatar user={user} showStatus />
      
      <div className="flex-1 min-w-0">
        <div className="flex justify-between items-center">
          <h4 className="font-medium text-slate-100 truncate">{user.name}</h4>
          <span className="text-xs text-slate-500">
            {lastMessage ? format(new Date(lastMessage.createdAt), 'HH:mm') : ''}
          </span>
        </div>
        
        {lastMessage ? (
          <div className="flex items-center gap-1 text-sm">
            {lastMessage.status && getStatusIcon(lastMessage.status)}
            <p className="truncate text-slate-400">
              {lastMessage.text}
            </p>
          </div>
        ) : (
          <p className="text-sm text-slate-500 italic">Start a conversation</p>
        )}
      </div>
    </motion.div>
  );
}