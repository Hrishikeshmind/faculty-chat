import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check } from 'lucide-react';
import { User } from '../../types';
import UserAvatar from '../ui/UserAvatar';

interface AddMembersDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onAddMembers: (userIds: string[]) => void;
  availableUsers: User[];
  currentMembers: string[];
}

export default function AddMembersDialog({
  isOpen,
  onClose,
  onAddMembers,
  availableUsers,
  currentMembers
}: AddMembersDialogProps) {
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);

  const filteredUsers = availableUsers.filter(user => !currentMembers.includes(user.id));

  const handleAddMembers = () => {
    if (selectedUsers.length > 0) {
      onAddMembers(selectedUsers);
      setSelectedUsers([]);
    }
    onClose();
  };

  const toggleUser = (userId: string) => {
    setSelectedUsers(prev =>
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
        >
          <motion.div
            initial={{ scale: 0.95 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0.95 }}
            className="bg-slate-900 rounded-xl shadow-xl w-full max-w-md"
          >
            <div className="flex items-center justify-between p-4 border-b border-slate-800">
              <h2 className="text-xl font-semibold text-slate-100">Add Members</h2>
              <button
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-slate-200 rounded-full hover:bg-slate-800"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-4">
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {filteredUsers.length === 0 ? (
                  <p className="text-center text-slate-400 py-4">
                    No users available to add
                  </p>
                ) : (
                  filteredUsers.map(user => (
                    <div
                      key={user.id}
                      onClick={() => toggleUser(user.id)}
                      className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors ${
                        selectedUsers.includes(user.id)
                          ? 'bg-blue-600/20 border border-blue-500/50'
                          : 'hover:bg-slate-800/50'
                      }`}
                    >
                      <UserAvatar user={user} size="sm" />
                      <span className="flex-1 text-slate-200">{user.name}</span>
                      {selectedUsers.includes(user.id) && (
                        <Check size={20} className="text-blue-500" />
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2 p-4 border-t border-slate-800">
              <button
                onClick={onClose}
                className="btn btn-secondary"
              >
                Cancel
              </button>
              <button
                onClick={handleAddMembers}
                className="btn btn-primary"
                disabled={selectedUsers.length === 0}
              >
                Add Selected ({selectedUsers.length})
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}