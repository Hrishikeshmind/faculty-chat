import { motion } from 'framer-motion';
import { MessageSquare } from 'lucide-react';

export default function LoadingScreen() {
  const bubbleVariants = {
    animate: {
      y: [0, -10, 0],
      transition: {
        duration: 1,
        repeat: Infinity,
        repeatType: "reverse" as const,
      }
    }
  };

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-background-darker">
      <div className="flex items-center gap-3 mb-8">
        <motion.div
          animate="animate"
          variants={bubbleVariants}
          className="text-blue-500"
          custom={0}
          transition={{ delay: 0 }}
        >
          <MessageSquare size={32} className="fill-blue-500" />
        </motion.div>
        <motion.div
          animate="animate"
          variants={bubbleVariants}
          className="text-violet-500"
          custom={1}
          transition={{ delay: 0.2 }}
        >
          <MessageSquare size={40} className="fill-violet-500" />
        </motion.div>
        <motion.div
          animate="animate"
          variants={bubbleVariants}
          className="text-blue-400"
          custom={2}
          transition={{ delay: 0.4 }}
        >
          <MessageSquare size={32} className="fill-blue-400" />
        </motion.div>
      </div>
      
      <motion.h1 
        className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        Faculty Chat
      </motion.h1>
      
      <motion.div 
        className="mt-8 flex flex-col items-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
      >
        <div className="w-24 h-1 bg-gradient-to-r from-blue-500 to-violet-500 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-white/20"
            initial={{ x: '-100%' }}
            animate={{ x: '100%' }}
            transition={{ 
              repeat: Infinity, 
              duration: 1.5,
              ease: "linear"
            }}
          />
        </div>
        <p className="text-slate-400 mt-4 text-sm">Loading your conversations...</p>
      </motion.div>
    </div>
  );
}