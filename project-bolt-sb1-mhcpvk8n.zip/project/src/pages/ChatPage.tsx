import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useChatStore } from '../stores/chatStore';
import { useUserStore } from '../stores/userStore';
import { useAuthStore } from '../stores/authStore';
import { Message } from '../types';
import ChatSidebar from '../components/chat/ChatSidebar';
import ChatHeader from '../components/chat/ChatHeader';
import MessageList from '../components/chat/MessageList';
import MessageInput from '../components/chat/MessageInput';
import LoadingScreen from '../components/ui/LoadingScreen';

export default function ChatPage() {
  const { chatId } = useParams();
  const { user } = useAuthStore();
  const { fetchMessages, messages, currentChat, typingUsers, isLoading } = useChatStore();
  const { users } = useUserStore();
  const [replyToMessage, setReplyToMessage] = useState<Message | null>(null);
  const [showSearch, setShowSearch] = useState(false);

  // Get participants excluding current user
  const participants = currentChat?.participants
    ? users.filter(u => currentChat.participants.includes(u.id) && u.id !== user?.id)
    : [];

  useEffect(() => {
    if (chatId) {
      fetchMessages(chatId);
    }
  }, [chatId, fetchMessages]);

  // Reset reply when changing chats
  useEffect(() => {
    setReplyToMessage(null);
  }, [chatId]);

  if (!user) {
    return <LoadingScreen />;
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <ChatSidebar />
      
      <div className="flex-1 flex flex-col">
        {chatId ? (
          <>
            {currentChat && (
              <ChatHeader 
                chat={currentChat}
                participants={participants}
                onOpenSearch={() => setShowSearch(!showSearch)}
                onAddMembers={() => {/* Add members handler */}}
              />
            )}
            
            {isLoading ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            ) : (
              <>
                <MessageList 
                  messages={messages} 
                  typingUser={typingUsers[chatId]} 
                  chatId={chatId}
                  onReply={(messageId) => {
                    const message = messages.find(m => m.id === messageId);
                    if (message) {
                      setReplyToMessage(message);
                    }
                  }}
                />
                <MessageInput 
                  chatId={chatId} 
                  replyToMessage={replyToMessage}
                  onCancelReply={() => setReplyToMessage(null)}
                />
              </>
            )}
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8">
            <div className="bg-slate-800/50 rounded-xl p-8 max-w-md text-center">
              <h2 className="text-2xl font-semibold text-slate-100 mb-3">Welcome to Faculty Chat</h2>
              <p className="text-slate-300 mb-6">
                Select a conversation from the sidebar or start a new chat to begin messaging.
              </p>
              <div className="flex justify-center">
                <button className="btn btn-primary">
                  Start a New Conversation
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}