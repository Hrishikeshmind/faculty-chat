import { motion } from 'framer-motion';
import { MessageSquare } from 'lucide-react';
import LoginForm from '../components/auth/LoginForm';

export default function LoginPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-b from-background-darker to-background-dark">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-8 flex flex-col items-center"
      >
        <div className="bg-gradient-to-r from-blue-600 to-violet-600 p-3 rounded-xl mb-4">
          <MessageSquare size={32} className="text-white" />
        </div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent">
          Faculty Chat
        </h1>
        <p className="text-slate-400 mt-2 text-center">
          Secure messaging platform for faculty members
        </p>
      </motion.div>

      <div className="w-full max-w-md bg-slate-900/80 border border-slate-800 rounded-xl shadow-2xl backdrop-blur-sm p-8">
        <h2 className="text-xl font-semibold text-center text-slate-100 mb-6">
          Login to your account
        </h2>
        <LoginForm />
      </div>
    </div>
  );
}