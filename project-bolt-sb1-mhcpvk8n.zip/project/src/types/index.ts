export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  status: 'online' | 'offline' | 'away';
  lastSeen: Date | null;
  department?: string;
  role?: string;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  text: string;
  createdAt: Date;
  status: 'sent' | 'delivered' | 'read';
  reactions: MessageReaction[];
  replyTo?: string | null;
  forwarded?: boolean;
  deleted?: {
    forMe: string[];
    forEveryone: boolean;
  };
}

export interface MessageReaction {
  userId: string;
  emoji: string;
}

export interface Chat {
  id: string;
  name?: string;
  isGroup: boolean;
  participants: string[];
  admins?: string[];
  avatar?: string;
  lastMessage?: Message;
  createdAt: Date;
  updatedAt: Date;
  archived?: boolean;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  checkAuth: () => void;
}

export interface ChatState {
  chats: Chat[];
  currentChat: Chat | null;
  messages: Message[];
  isLoading: boolean;
  error: string | null;
  typingUsers: Record<string, boolean>;
  fetchChats: () => Promise<void>;
  fetchMessages: (chatId: string) => Promise<void>;
  sendMessage: (chatId: string, text: string, replyToMessageId?: string) => Promise<void>;
  forwardMessage: (messageId: string, targetChatIds: string[]) => Promise<void>;
  deleteMessage: (messageId: string, type: 'me' | 'everyone') => Promise<void>;
  setMessageStatus: (messageId: string, status: Message['status']) => void;
  addReaction: (messageId: string, emoji: string) => void;
  setTypingStatus: (chatId: string, isTyping: boolean) => void;
  createGroup: (name: string, participants: string[]) => Promise<void>;
  addMembersToChat: (chatId: string, userIds: string[]) => Promise<void>;
  removeMemberFromChat: (chatId: string, userId: string) => Promise<void>;
  archiveChat: (chatId: string) => Promise<void>;
  unarchiveChat: (chatId: string) => Promise<void>;
}

export interface UserState {
  users: User[];
  isLoading: boolean;
  error: string | null;
  fetchUsers: () => Promise<void>;
  updateUserStatus: (userId: string, status: User['status']) => void;
  updateLastSeen: (userId: string) => void;
}