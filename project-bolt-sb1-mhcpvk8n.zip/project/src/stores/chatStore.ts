import { create } from 'zustand';
import { nanoid } from 'nanoid';
import { ChatState, Chat, Message } from '../types';
import { useAuthStore } from './authStore';
import { useUserStore } from './userStore';

// Mock chats with group support
const MOCK_CHATS: Chat[] = [
  {
    id: 'chat1',
    participants: ['1', '2'],
    isGroup: false,
    createdAt: new Date(2023, 10, 15),
    updatedAt: new Date(2023, 11, 20)
  },
  {
    id: 'chat2',
    name: 'Computer Science Faculty',
    participants: ['1', '2', '3', '4'],
    isGroup: true,
    admins: ['1'],
    avatar: undefined,
    createdAt: new Date(2023, 9, 10),
    updatedAt: new Date(2023, 11, 19)
  }
];

// Mock messages
const MOCK_MESSAGES: Record<string, Message[]> = {
  'chat1': [
    {
      id: 'msg1',
      chatId: 'chat1',
      senderId: '1',
      text: 'Hello Sarah, how are you doing?',
      createdAt: new Date(2023, 11, 20, 10, 30),
      status: 'read',
      reactions: []
    },
    {
      id: 'msg2',
      chatId: 'chat1',
      senderId: '2',
      text: 'Hi John! I\'m doing well, thanks for asking. How about you?',
      createdAt: new Date(2023, 11, 20, 10, 32),
      status: 'read',
      reactions: [{ userId: '1', emoji: '👍' }]
    }
  ],
  'chat2': [
    {
      id: 'msg5',
      chatId: 'chat2',
      senderId: '3',
      text: 'John, did you get my email about the research proposal?',
      createdAt: new Date(2023, 11, 19, 14, 15),
      status: 'read',
      reactions: []
    },
    {
      id: 'msg6',
      chatId: 'chat2',
      senderId: '1',
      text: 'Yes, I reviewed it already. Let\'s discuss the changes tomorrow.',
      createdAt: new Date(2023, 11, 19, 14, 20),
      status: 'read',
      reactions: [{ userId: '3', emoji: '👍' }]
    }
  ]
};

export const useChatStore = create<ChatState>((set, get) => ({
  chats: [],
  currentChat: null,
  messages: [],
  isLoading: false,
  error: null,
  typingUsers: {},

  fetchChats: async () => {
    set({ isLoading: true, error: null });
    
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const currentUser = useAuthStore.getState().user;
      
      if (!currentUser) {
        set({ error: 'User not authenticated', isLoading: false });
        return;
      }
      
      const userChats = MOCK_CHATS.filter(chat => 
        chat.participants.includes(currentUser.id)
      );
      
      const userChatsWithLastMessage = userChats.map(chat => {
        const chatMessages = MOCK_MESSAGES[chat.id] || [];
        const lastMessage = chatMessages.length > 0 
          ? chatMessages[chatMessages.length - 1] 
          : undefined;
          
        return {
          ...chat,
          lastMessage
        };
      });
      
      set({ 
        chats: userChatsWithLastMessage, 
        isLoading: false 
      });
    } catch (error) {
      set({ error: 'Failed to fetch chats', isLoading: false });
    }
  },

  fetchMessages: async (chatId) => {
    set({ isLoading: true, error: null });
    
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const chat = MOCK_CHATS.find(c => c.id === chatId);
      
      if (!chat) {
        set({ error: 'Chat not found', isLoading: false });
        return;
      }
      
      const messages = MOCK_MESSAGES[chatId] || [];
      
      set({ 
        currentChat: chat, 
        messages: messages.filter(m => !m.deleted?.forMe.includes(useAuthStore.getState().user?.id || '')), 
        isLoading: false 
      });
      
      const currentUserId = useAuthStore.getState().user?.id;
      
      if (currentUserId) {
        messages.forEach(msg => {
          if (msg.senderId !== currentUserId && msg.status !== 'read') {
            get().setMessageStatus(msg.id, 'read');
          }
        });
      }
    } catch (error) {
      set({ error: 'Failed to fetch messages', isLoading: false });
    }
  },

  sendMessage: async (chatId, text, replyToMessageId) => {
    const currentUser = useAuthStore.getState().user;
    
    if (!currentUser) {
      set({ error: 'User not authenticated' });
      return;
    }
    
    const newMessage: Message = {
      id: nanoid(),
      chatId,
      senderId: currentUser.id,
      text,
      createdAt: new Date(),
      status: 'sent',
      reactions: [],
      replyTo: replyToMessageId
    };
    
    set(state => ({
      messages: [...state.messages, newMessage]
    }));
    
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      
      set(state => ({
        chats: state.chats.map(chat => 
          chat.id === chatId 
            ? { ...chat, lastMessage: newMessage, updatedAt: new Date() } 
            : chat
        )
      }));
      
      setTimeout(() => {
        get().setMessageStatus(newMessage.id, 'delivered');
      }, 1000);
      
      setTimeout(() => {
        get().setMessageStatus(newMessage.id, 'read');
      }, 2000);
    } catch (error) {
      set({ error: 'Failed to send message' });
    }
  },

  forwardMessage: async (messageId, targetChatIds) => {
    const message = get().messages.find(m => m.id === messageId);
    const currentUser = useAuthStore.getState().user;
    
    if (!message || !currentUser) {
      return;
    }
    
    for (const chatId of targetChatIds) {
      const forwardedMessage: Message = {
        id: nanoid(),
        chatId,
        senderId: currentUser.id,
        text: message.text,
        createdAt: new Date(),
        status: 'sent',
        reactions: [],
        forwarded: true
      };
      
      set(state => ({
        messages: [...state.messages, forwardedMessage],
        chats: state.chats.map(chat => 
          chat.id === chatId 
            ? { ...chat, lastMessage: forwardedMessage, updatedAt: new Date() } 
            : chat
        )
      }));
    }
  },

  deleteMessage: async (messageId, type) => {
    const currentUser = useAuthStore.getState().user;
    
    if (!currentUser) {
      return;
    }
    
    if (type === 'me') {
      set(state => ({
        messages: state.messages.map(msg => 
          msg.id === messageId
            ? {
                ...msg,
                deleted: {
                  ...msg.deleted,
                  forMe: [...(msg.deleted?.forMe || []), currentUser.id]
                }
              }
            : msg
        )
      }));
    } else {
      set(state => ({
        messages: state.messages.map(msg => 
          msg.id === messageId
            ? {
                ...msg,
                deleted: {
                  ...msg.deleted,
                  forEveryone: true
                }
              }
            : msg
        )
      }));
    }
  },

  setMessageStatus: (messageId, status) => {
    set(state => ({
      messages: state.messages.map(msg => 
        msg.id === messageId ? { ...msg, status } : msg
      )
    }));
  },

  addReaction: (messageId, emoji) => {
    const currentUser = useAuthStore.getState().user;
    
    if (!currentUser) {
      return;
    }
    
    set(state => ({
      messages: state.messages.map(msg => {
        if (msg.id === messageId) {
          const existingReaction = msg.reactions.findIndex(
            r => r.userId === currentUser.id && r.emoji === emoji
          );
          
          if (existingReaction > -1) {
            const newReactions = [...msg.reactions];
            newReactions.splice(existingReaction, 1);
            return { ...msg, reactions: newReactions };
          } else {
            return {
              ...msg,
              reactions: [...msg.reactions, { userId: currentUser.id, emoji }]
            };
          }
        }
        return msg;
      })
    }));
  },

  setTypingStatus: (chatId, isTyping) => {
    const currentUser = useAuthStore.getState().user;
    
    if (!currentUser) {
      return;
    }
    
    set(state => ({
      typingUsers: {
        ...state.typingUsers,
        [chatId]: isTyping
      }
    }));
    
    if (isTyping) {
      setTimeout(() => {
        set(state => ({
          typingUsers: {
            ...state.typingUsers,
            [chatId]: false
          }
        }));
      }, 3000);
    }
  },

  createGroup: async (name: string, participants: string[]) => {
    const currentUser = useAuthStore.getState().user;
    
    if (!currentUser) {
      set({ error: 'User not authenticated' });
      return;
    }
    
    const newGroup: Chat = {
      id: nanoid(),
      name,
      isGroup: true,
      participants: [currentUser.id, ...participants],
      admins: [currentUser.id],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    set(state => ({
      chats: [...state.chats, newGroup]
    }));
  },

  addMembersToChat: async (chatId: string, userIds: string[]) => {
    set(state => ({
      chats: state.chats.map(chat => 
        chat.id === chatId
          ? {
              ...chat,
              participants: [...new Set([...chat.participants, ...userIds])],
              updatedAt: new Date()
            }
          : chat
      )
    }));
  },

  removeMemberFromChat: async (chatId: string, userId: string) => {
    set(state => ({
      chats: state.chats.map(chat => 
        chat.id === chatId
          ? {
              ...chat,
              participants: chat.participants.filter(id => id !== userId),
              admins: chat.admins?.filter(id => id !== userId),
              updatedAt: new Date()
            }
          : chat
      )
    }));
  },

  archiveChat: async (chatId: string) => {
    set(state => ({
      chats: state.chats.map(chat =>
        chat.id === chatId
          ? { ...chat, archived: true }
          : chat
      )
    }));
  },

  unarchiveChat: async (chatId: string) => {
    set(state => ({
      chats: state.chats.map(chat =>
        chat.id === chatId
          ? { ...chat, archived: false }
          : chat
      )
    }));
  }
}));