import { create } from 'zustand';
import { nanoid } from 'nanoid';
import { AuthState, User } from '../types';

// Mock users for demonstration
const MOCK_USERS: User[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john.smith@faculty.edu',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    status: 'online',
    lastSeen: null,
    department: 'Computer Science',
    role: 'Professor'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah.johnson@faculty.edu',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    status: 'online',
    lastSeen: null,
    department: 'Mathematics',
    role: 'Assistant Professor'
  }
];

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  error: null,

  checkAuth: () => {
    // Check if user is stored in localStorage (in a real app)
    const storedUser = localStorage.getItem('user');
    
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser);
        set({ user, isAuthenticated: true, isLoading: false });
      } catch (error) {
        localStorage.removeItem('user');
        set({ isLoading: false });
      }
    } else {
      set({ isLoading: false });
    }
  },

  login: async (email, password) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Find matching user (in a real app, this would be an API call)
      const user = MOCK_USERS.find(u => u.email === email);
      
      if (user && password === 'password') { // Simple mock password check
        localStorage.setItem('user', JSON.stringify(user));
        set({ user, isAuthenticated: true, isLoading: false });
      } else {
        set({ error: 'Invalid email or password', isLoading: false });
      }
    } catch (error) {
      set({ error: 'Failed to login', isLoading: false });
    }
  },

  signup: async (name, email, password) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if email is already registered
      if (MOCK_USERS.some(u => u.email === email)) {
        set({ error: 'Email already registered', isLoading: false });
        return;
      }
      
      // Create new user (in a real app, this would be an API call)
      const newUser: User = {
        id: nanoid(),
        name,
        email,
        avatar: `https://images.pexels.com/photos/1310474/pexels-photo-1310474.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2`,
        status: 'online',
        lastSeen: null,
        department: 'Faculty',
      };
      
      // MOCK_USERS.push(newUser); - In a real app, this would be saved to a database
      
      localStorage.setItem('user', JSON.stringify(newUser));
      set({ user: newUser, isAuthenticated: true, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to sign up', isLoading: false });
    }
  },

  logout: () => {
    localStorage.removeItem('user');
    set({ user: null, isAuthenticated: false });
  }
}));