import { create } from 'zustand';
import { UserState, User } from '../types';

// Mock users data
const MOCK_USERS: User[] = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john.smith@faculty.edu',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    status: 'online',
    lastSeen: null,
    department: 'Computer Science',
    role: 'Professor'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah.johnson@faculty.edu',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    status: 'online',
    lastSeen: null,
    department: 'Mathematics',
    role: 'Assistant Professor'
  },
  {
    id: '3',
    name: 'Michael Brown',
    email: 'michael.brown@faculty.edu',
    avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    status: 'offline',
    lastSeen: new Date(2023, 11, 19, 18, 30),
    department: 'Physics',
    role: 'Associate Professor'
  },
  {
    id: '4',
    name: 'Emily Davis',
    email: 'emily.davis@faculty.edu',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    status: 'away',
    lastSeen: new Date(2023, 11, 20, 9, 15),
    department: 'Chemistry',
    role: 'Professor'
  },
  {
    id: '5',
    name: 'David Wilson',
    email: 'david.wilson@faculty.edu',
    avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    status: 'online',
    lastSeen: null,
    department: 'Biology',
    role: 'Assistant Professor'
  }
];

export const useUserStore = create<UserState>((set) => ({
  users: [],
  isLoading: false,
  error: null,

  fetchUsers: async () => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      set({ users: MOCK_USERS, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch users', isLoading: false });
    }
  },

  updateUserStatus: (userId, status) => {
    set(state => ({
      users: state.users.map(user => 
        user.id === userId 
          ? { 
              ...user, 
              status, 
              lastSeen: status === 'offline' ? new Date() : user.lastSeen 
            } 
          : user
      )
    }));
  },

  updateLastSeen: (userId: string) => {
    set(state => ({
      users: state.users.map(user =>
        user.id === userId
          ? {
              ...user,
              lastSeen: new Date(),
              status: 'offline'
            }
          : user
      )
    }));
  }
}));